
#ifndef DISCOVERY_H
#define DISCOVERY_H

#include "peer.h"
#include <functional>
#include <string>

// --- THIS IS THE FIX ---
// The callback now provides both the IP and the alphanumeric peer ID.
using DiscoveryCb = std::function<void(const std::string&, const std::string&)>;

class Discovery {
public:
    Discovery();
    ~Discovery();
    // --- The local peer's ID is now passed to start() ---
    bool start(int listen_port, const std::string& local_peer_id);
    void stop();
    void setCallback(DiscoveryCb cb);
private:
    class DiscoveryImpl* m_impl;
};

// Singleton accessor
Discovery* getGlobalDiscoveryInstance();

#endif // DISCOVERY_H
