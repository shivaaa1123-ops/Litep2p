#ifndef _AES_H_
#define _AES_H_

#include <stdint.h>

// #define AES128 1
#define AES192 1
// #define AES256 1

#if defined(AES256) && (AES256 == 1)
    #define KEYLEN 32
    #define N_ROUNDS 14
#elif defined(AES192) && (AES192 == 1)
    #define KEYLEN 24
    #define N_ROUNDS 12
#else
    #define KEYLEN 16
    #define N_ROUNDS 10
#endif

#define AES_BLOCKLEN 16 

struct AES_ctx {
    uint8_t RoundKey[N_ROUNDS * AES_BLOCKLEN];
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);
void AES_CBC_encrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);
void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);

#endif // _AES_H_
