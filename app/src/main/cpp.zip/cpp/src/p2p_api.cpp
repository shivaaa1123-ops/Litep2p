
#include <jni.h>
#include <string>
#include <vector>
#include "peer_manager.h"
#include "discovery.h"
#include "logger.h"
#include "jni_glue.h"

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_zeengal_litep2p_MainActivity_nativeStartLiteP2P(JNIEnv* env, jobject thiz) {
    nativeLog("P2P_API: MainActivity_nativeStartLiteP2P called.");
    
    // --- THIS IS THE FIX ---
    // Initialize the JNI glue on the main thread
    if (!jniGlueInit(env)) {
        return env->NewStringUTF("JNI Init Failed");
    }

    g_peerManager.setPeerUpdateCallback([](const std::vector<Peer>& peers) {
        sendPeersToUI(peers);
    });

    Discovery* disc = getGlobalDiscoveryInstance();
    if (disc) {
        disc->setCallback([](const Peer& p) {
            g_peerManager.addPeer(p);
        });
    }

    g_peerManager.start(12345);
    if (disc) disc->start(12345);
    return env->NewStringUTF("LiteP2P Started");
}

JNIEXPORT void JNICALL
Java_com_zeengal_litep2p_MainActivity_nativeStopLiteP2P(JNIEnv* env, jobject thiz) {
    nativeLog("P2P: Stop");
    jniGlueCleanup(env); // Clean up the global references
    Discovery* disc = getGlobalDiscoveryInstance();
    if (disc) disc->stop();
    g_peerManager.stop();
}


JNIEXPORT void JNICALL
Java_com_zeengal_litep2p_hook_P2P_init(JNIEnv* env, jclass clazz) {
    // This function can be used if you need initialization separate from starting the server
    g_peerManager.setPeerUpdateCallback([](const std::vector<Peer>& peers) {
        sendPeersToUI(peers);
    });
    Discovery* disc = getGlobalDiscoveryInstance();
    if (disc) {
        disc->setCallback([](const Peer& p) {
            g_peerManager.addPeer(p);
        });
    }
}

JNIEXPORT void JNICALL
Java_com_zeengal_litep2p_hook_P2P_startServer(JNIEnv* env, jclass, jint port) {
    g_peerManager.start(port);
    Discovery* disc = getGlobalDiscoveryInstance();
    if (disc) disc->start(port);
}

JNIEXPORT void JNICALL
Java_com_zeengal_litep2p_hook_P2P_connect(JNIEnv* env, jclass, jstring jip, jint port) {
    if (!jip) return;
    const char* ip = env->GetStringUTFChars(jip, nullptr);
    g_peerManager.connectTo(ip, port);
    env->ReleaseStringUTFChars(jip, ip);
}

JNIEXPORT void JNICALL
Java_com_zeengal_litep2p_hook_P2P_sendMessage(JNIEnv* env, jclass, jstring jid, jbyteArray jdata) {
    if (!jid || !jdata) return;
    const char* id = env->GetStringUTFChars(jid, nullptr);
    jsize len = env->GetArrayLength(jdata);
    std::vector<uint8_t> buf(len);
    env->GetByteArrayRegion(jdata, 0, len, (jbyte*)buf.data());
    std::string s((char*)buf.data(), len);
    g_peerManager.sendDirect(id, s);
    env->ReleaseStringUTFChars(jid, id);
}

JNIEXPORT void JNICALL
Java_com_zeengal_litep2p_hook_P2P_stop(JNIEnv* env, jclass) {
    nativeLog("P2P: Stop");
    Discovery* disc = getGlobalDiscoveryInstance();
    if (disc) disc->stop();
    g_peerManager.stop();
}

} // extern C
