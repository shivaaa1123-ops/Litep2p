#include "protocol.h"
// All inline helpers in header
