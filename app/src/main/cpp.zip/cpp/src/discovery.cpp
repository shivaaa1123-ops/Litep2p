
#include "discovery.h"
#include "logger.h"
#include <thread>
#include <atomic>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <mutex>

static Discovery g_instance;

class DiscoveryImpl {
public:
    DiscoveryImpl() : m_running(false), m_sock(-1) {}
    ~DiscoveryImpl() { stop(); }

    bool start(int listenPort, const std::string& localPeerId) {
        if (m_running) return false;
        m_localPeerId = localPeerId;
        m_listenPort = listenPort;

        m_sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (m_sock < 0) {
            nativeLog("Discovery Error: Failed to create socket.");
            return false;
        }

        int on = 1;
        if (setsockopt(m_sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
            nativeLog("Discovery Error: Failed to set SO_REUSEADDR.");
            close(m_sock);
            return false;
        }
        if (setsockopt(m_sock, SOL_SOCKET, SO_BROADCAST, &on, sizeof(on)) < 0) {
            nativeLog("Discovery Error: Failed to set SO_BROADCAST.");
            close(m_sock);
            return false;
        }

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(m_listenPort);
        if (bind(m_sock, (sockaddr*)&addr, sizeof(addr)) < 0) {
            nativeLog("Discovery Error: Failed to bind socket.");
            close(m_sock);
            return false;
        }

        m_running = true;

        m_listenThread = std::thread(&DiscoveryImpl::listenLoop, this);
        m_broadcastThread = std::thread(&DiscoveryImpl::broadcastLoop, this);
        
        nativeLog("Discovery service started successfully.");
        return true;
    }

    void stop() {
        m_running = false;
        if (m_sock >= 0) {
            shutdown(m_sock, SHUT_RDWR);
            close(m_sock);
            m_sock = -1;
        }
        if (m_listenThread.joinable()) m_listenThread.join();
        if (m_broadcastThread.joinable()) m_broadcastThread.join();
        nativeLog("Discovery service stopped.");
    }

    void setCb(DiscoveryCb cb) {
        std::lock_guard<std::mutex> lock(m_cbMutex);
        m_cb = cb;
    }

private:
    void listenLoop() {
        char buf[1024];
        while (m_running) {
            sockaddr_in from{};
            socklen_t len = sizeof(from);
            ssize_t n = recvfrom(m_sock, buf, sizeof(buf)-1, 0, (sockaddr*)&from, &len);
            if (n > 0) {
                buf[n] = 0;
                std::string msg(buf);
                
                if (msg.rfind("LITEP2P_PEER:", 0) == 0) {
                    std::string peerId = msg.substr(13);

                    if (peerId == m_localPeerId) continue;

                    char senderIp[64];
                    inet_ntop(AF_INET, &from.sin_addr, senderIp, sizeof(senderIp));
                    nativeLog("Discovery: Received announcement from " + peerId);
                    
                    if (m_cb) {
                        m_cb(std::string(senderIp), peerId);
                    }
                }
            }
        }
    }

    void broadcastLoop() {
        while (m_running) {
            sockaddr_in dest{};
            dest.sin_family = AF_INET;
            dest.sin_port = htons(m_listenPort);
            dest.sin_addr.s_addr = inet_addr("255.255.255.255");
            
            std::string msg = "LITEP2P_PEER:" + m_localPeerId;
            nativeLog("Discovery: Broadcasting our presence...");
            
            ssize_t bytes_sent = sendto(m_sock, msg.c_str(), msg.size(), 0, (sockaddr*)&dest, sizeof(dest));
            if (bytes_sent < 0) {
                nativeLog("Discovery Error: Failed to send broadcast packet: " + std::string(strerror(errno)));
            }
            
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    }

    std::atomic<bool> m_running;
    int m_sock;
    int m_listenPort;
    std::thread m_listenThread, m_broadcastThread;
    std::mutex m_cbMutex;
    DiscoveryCb m_cb;
    std::string m_localPeerId;
};

Discovery* getGlobalDiscoveryInstance() { return &g_instance; }
Discovery::Discovery() : m_impl(new DiscoveryImpl()) {}
Discovery::~Discovery() { delete m_impl; }
bool Discovery::start(int p, const std::string& pid) { return m_impl->start(p, pid); }
void Discovery::stop() { m_impl->stop(); }
void Discovery::setCallback(DiscoveryCb cb) { m_impl->setCb(cb); }
