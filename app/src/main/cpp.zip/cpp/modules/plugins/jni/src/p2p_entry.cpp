// P2P Entry implementation stub
