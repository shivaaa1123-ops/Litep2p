#ifndef SESSION_MANAGER_H
#define SESSION_MANAGER_H

#include "peer.h"
#include "connection_manager.h"
#include "udp_connection_manager.h"
#include "battery_optimizer.h"
#include "session_cache.h"
#include "message_batcher.h"
#include "peer_index.h"
#include "noise_nk.h"
#include "noise_key_store.h"
#include "nat_traversal.h"
#include "peer_reconnect_policy.h"
#include "peer_tier_manager.h"
// #include "broadcast_discovery_manager.h"  // Disabled: discovery module requires code fixes
#include "tier_system_failsafe.h"
// #include "file_transfer_manager.h"  // Disabled: file_transfer depends on session
#include <vector>
#include <string>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <memory>

class SessionManager {
public:
    SessionManager();
    ~SessionManager();

    void start(int port, std::function<void(const std::vector<Peer>&)> peer_update_cb, const std::string& comms_mode, const std::string& peer_id);
    void stop();

    void connectToPeer(const std::string& peer_id);
    void sendMessageToPeer(const std::string& peer_id, const std::string& message);

    // Battery optimization APIs
    void set_optimization_level(BatteryOptimizer::OptimizationLevel level);
    void set_network_type(BatteryOptimizer::NetworkType type);
    int get_cached_session_count() const;
    int get_session_cache_hit_rate() const;
    BatteryOptimizer::OptimizationConfig get_optimization_config() const;

    // Noise NK MITM Protection APIs
    // =============================
    
    /**
     * Enable Noise NK pattern for MITM protection
     * Call this before starting if you want NK-protected channels
     * Requires peer static keys to be registered first
     */
    void enable_noise_nk();

    /**
     * Check if Noise NK is enabled
     */
    bool is_noise_nk_enabled() const;

    /**
     * Get local static public key (to share with peers)
     * Share this via QR code, NFC, or initial setup
     */
    std::vector<uint8_t> get_local_static_public_key() const;

    /**
     * Register peer's static public key
     * Must be done before initiating NK handshake with peer
     * In production: load from QR code scan, NFC, or provisioning server
     */
    void register_peer_nk_key(const std::string& peer_id, const std::vector<uint8_t>& static_pk);

    /**
     * Check if peer's NK key is registered
     */
    bool has_peer_nk_key(const std::string& peer_id) const;

    /**
     * Get number of registered peer NK keys
     */
    int get_nk_peer_count() const;

    /**
     * Get all known peer IDs (with NK keys)
     */
    std::vector<std::string> get_nk_peer_ids() const;

    /**
     * Import peer keys from hex-encoded map (for restoring from backup)
     */
    bool import_nk_peer_keys_hex(const std::map<std::string, std::string>& hex_keys);

    /**
     * Export peer keys as hex-encoded strings (for backup/sharing)
     */
    std::map<std::string, std::string> export_nk_peer_keys_hex() const;

    // NAT Traversal & Reconnect APIs
    /**
     * Set battery level (0-100%) and charging state
     * Called from Android BatteryReceiver
     */
    void set_battery_level(int percent, bool is_charging);

    /**
     * Set network type and availability
     * Called from Android NetworkReceiver
     */
    void set_network_info(bool is_wifi, bool is_available);

    /**
     * Get reconnection status as JSON
     * Contains peer connection state, retry info, network condition
     */
    std::string get_reconnect_status_json() const;

    // File Transfer APIs
    // ==================
    /**
     * Send a file to a peer via optimal network path(s)
     * @param file_path Local file path
     * @param peer_id Destination peer ID
     * @param peer_ip Peer IP address
     * @param peer_port Peer port
     * @param priority Transfer priority (LOW, NORMAL, HIGH)
     * @param strategy Path selection strategy (LATENCY, THROUGHPUT, BALANCED, COST)
     * @return Transfer ID (empty string on error)
     */
    std::string send_file(const std::string& file_path, const std::string& peer_id,
                         const std::string& peer_ip, int peer_port,
                         TransferPriority priority = TransferPriority::NORMAL,
                         PathSelectionStrategy strategy = PathSelectionStrategy::BALANCED);

    /**
     * Receive a file from a peer
     * @param transfer_id Unique transfer ID
     * @param destination_path Where to save the file
     * @param peer_id Source peer ID
     * @param peer_ip Source peer IP
     * @param peer_port Source peer port
     * @param file_size Expected file size in bytes
     * @return true on success
     */
    bool receive_file(const std::string& transfer_id, const std::string& destination_path,
                     const std::string& peer_id, const std::string& peer_ip,
                     int peer_port, uint64_t file_size);

    /**
     * Pause an ongoing transfer
     */
    bool pause_transfer(const std::string& transfer_id);

    /**
     * Resume a paused transfer
     */
    bool resume_transfer(const std::string& transfer_id);

    /**
     * Cancel a transfer
     */
    bool cancel_transfer(const std::string& transfer_id);

    /**
     * Register a network path with metrics
     */
    std::string register_network_path(const std::string& peer_id, const std::string& next_hop,
                                     const std::string& ip, int port, int latency_ms, int bandwidth_kbps);

    /**
     * Get optimal path for a peer
     */
    std::string find_optimal_path(const std::string& peer_id, PathSelectionStrategy strategy);

    /**
     * Get transfer progress (0.0 - 1.0)
     */
    float get_transfer_progress(const std::string& transfer_id) const;

    /**
     * Get transfer speed in KB/s
     */
    float get_transfer_speed(const std::string& transfer_id) const;

    /**
     * Get list of active transfer IDs
     */
    std::vector<std::string> get_active_transfers() const;

    /**
     * Report congestion for adaptive rate limiting
     */
    void report_congestion(const std::string& path_id, const CongestionMetrics& metrics);

    /**
     * Get current adaptive rate limit in Kbps
     */
    uint32_t get_adaptive_rate_limit() const;

    /**
     * Check if a paused transfer can be resumed
     */
    bool can_resume_transfer(const std::string& checkpoint_path) const;

private:
    class Impl;
    std::unique_ptr<Impl> m_impl;
};

#endif // SESSION_MANAGER_H
