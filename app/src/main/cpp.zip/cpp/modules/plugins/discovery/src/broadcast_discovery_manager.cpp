#include "../include/broadcast_discovery_manager.h"
#include "../include/logger.h"
#include <algorithm>
#include <sstream>
#include <chrono>
#include <cstring>
#include <random>

BroadcastDiscoveryManager::BroadcastDiscoveryManager(const BroadcastDiscoveryConfig& config)
    : m_config(config), m_running(false) {
    m_request_counter = 0;
    m_last_error = "";
}

BroadcastDiscoveryManager::~BroadcastDiscoveryManager() {
    shutdown();
}

bool BroadcastDiscoveryManager::initialize() {
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        if (m_running) {
            log_warn("BroadcastDiscoveryManager", "Already initialized");
            return true;
        }
        
        // Validate configuration
        if (m_config.ttl <= 0 || m_config.ttl > 255) {
            m_last_error = "Invalid TTL: " + std::to_string(m_config.ttl);
            return false;
        }
        
        if (m_config.dedup_cache_size <= 0) {
            m_last_error = "Invalid dedup_cache_size: " + std::to_string(m_config.dedup_cache_size);
            return false;
        }
        
        if (m_config.response_timeout_sec <= 0) {
            m_last_error = "Invalid response_timeout_sec: " + std::to_string(m_config.response_timeout_sec);
            return false;
        }
        
        // Initialize deduplication cache
        m_dedup_cache.clear();
        m_peer_broadcast_count.clear();
        m_pending_discoveries.clear();
        
        m_running = true;
        
        // Start background threads
        m_cleanup_thread = std::thread([this] { cleanup_loop(); });
        m_timeout_thread = std::thread([this] { response_timeout_loop(); });
        
        log_info("BroadcastDiscoveryManager", "Initialized with TTL=" + std::to_string(m_config.ttl) +
                                              ", dedup_size=" + std::to_string(m_config.dedup_cache_size));
        
        return true;
    } catch (const std::exception& e) {
        m_last_error = "Initialization failed: " + std::string(e.what());
        log_error("BroadcastDiscoveryManager", m_last_error);
        return false;
    }
}

void BroadcastDiscoveryManager::shutdown() {
    try {
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            
            if (!m_running) {
                return;
            }
            
            m_running = false;
        }
        
        // Wait for threads to finish
        if (m_cleanup_thread.joinable()) {
            m_cleanup_thread.join();
        }
        if (m_timeout_thread.joinable()) {
            m_timeout_thread.join();
        }
        
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_dedup_cache.clear();
            m_peer_broadcast_count.clear();
            m_pending_discoveries.clear();
        }
        
        log_info("BroadcastDiscoveryManager", "Shutdown complete");
    } catch (const std::exception& e) {
        log_error("BroadcastDiscoveryManager", "Shutdown error: " + std::string(e.what()));
    }
}

uint64_t BroadcastDiscoveryManager::discover_peer(const std::string& peer_id,
                                                  const std::string& source_peer,
                                                  DiscoveryCallback callback) {
    try {
        // Validate input
        if (peer_id.empty() || peer_id.length() > 256) {
            log_error("BroadcastDiscoveryManager", "Invalid peer_id");
            return 0;
        }
        
        if (source_peer.empty() || source_peer.length() > 256) {
            log_error("BroadcastDiscoveryManager", "Invalid source_peer");
            return 0;
        }
        
        std::lock_guard<std::mutex> lock(m_mutex);
        
        if (!m_running) {
            m_last_error = "Discovery manager not running";
            return 0;
        }
        
        // Check if already discovering this peer
        for (const auto& [request_id, pending] : m_pending_discoveries) {
            if (pending.target_peer == peer_id && pending.source_peer == source_peer) {
                log_warn("BroadcastDiscoveryManager", 
                        "Already discovering peer: " + peer_id);
                return request_id;
            }
        }
        
        // Generate request ID
        uint64_t request_id = ++m_request_counter;
        
        // Create pending discovery
        PendingDiscovery pending;
        pending.request_id = request_id;
        pending.target_peer = peer_id;
        pending.source_peer = source_peer;
        pending.start_time = std::chrono::steady_clock::now();
        pending.callback = callback;
        pending.response_count = 0;
        pending.best_latency = std::numeric_limits<int>::max();
        
        m_pending_discoveries[request_id] = pending;
        
        log_info("BroadcastDiscoveryManager", 
                "Discovery initiated for peer: " + peer_id + " (request_id=" + 
                std::to_string(request_id) + ")");
        
        // Schedule cleanup if callback registered
        if (callback) {
            m_discovery_callbacks[request_id] = callback;
        }
        
        return request_id;
    } catch (const std::exception& e) {
        m_last_error = "discover_peer failed: " + std::string(e.what());
        log_error("BroadcastDiscoveryManager", m_last_error);
        return 0;
    }
}

bool BroadcastDiscoveryManager::cancel_discovery(uint64_t request_id) {
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        auto it = m_pending_discoveries.find(request_id);
        if (it == m_pending_discoveries.end()) {
            m_last_error = "Discovery request not found: " + std::to_string(request_id);
            return false;
        }
        
        m_pending_discoveries.erase(it);
        m_discovery_callbacks.erase(request_id);
        
        log_info("BroadcastDiscoveryManager", 
                "Discovery cancelled: request_id=" + std::to_string(request_id));
        
        return true;
    } catch (const std::exception& e) {
        m_last_error = "cancel_discovery failed: " + std::string(e.what());
        return false;
    }
}

bool BroadcastDiscoveryManager::process_broadcast_message(const BroadcastMessage& message) {
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        if (!m_running) {
            return false;
        }
        
        // Validate message
        if (message.request_id == 0) {
            log_error("BroadcastDiscoveryManager", "Invalid request_id in broadcast");
            return false;
        }
        
        if (message.source_peer.empty()) {
            log_error("BroadcastDiscoveryManager", "Invalid source_peer in broadcast");
            return false;
        }
        
        if (message.ttl <= 0) {
            log_warn("BroadcastDiscoveryManager", "TTL expired for broadcast");
            return false;
        }
        
        // Check for duplicates
        std::string dedup_key = message.source_peer + "_" + std::to_string(message.request_id);
        if (is_broadcast_duplicate(dedup_key)) {
            log_debug("BroadcastDiscoveryManager", "Duplicate broadcast dropped");
            return false;
        }
        
        // Mark as seen
        mark_broadcast_seen(dedup_key);
        
        // Record broadcast
        record_peer_broadcast(message.source_peer);
        
        // Check if this is for us
        if (!message.target_peer.empty() && message.target_peer == message.source_peer) {
            // This is a response to our discovery request
            process_discovery_response(message);
        }
        
        return true;
    } catch (const std::exception& e) {
        m_last_error = "process_broadcast_message failed: " + std::string(e.what());
        log_error("BroadcastDiscoveryManager", m_last_error);
        return false;
    }
}

bool BroadcastDiscoveryManager::should_relay_broadcast(const BroadcastMessage& message,
                                                       const std::string& my_peer_id) {
    try {
        if (message.ttl <= 0 || message.ttl > m_config.ttl) {
            return false;
        }
        
        if (message.hop_count >= m_config.ttl) {
            return false;
        }
        
        // Check if we're the source
        if (message.source_peer == my_peer_id) {
            return false;
        }
        
        // Don't relay if this is already relayed many times
        if (message.hop_count > m_config.ttl / 2) {
            // Maybe relay with lower probability
            std::random_device rd;
            std::mt19937 gen(rd());
            std::uniform_int_distribution<> dis(0, 99);
            return dis(gen) < 25;  // 25% chance
        }
        
        return true;
    } catch (const std::exception& e) {
        log_error("BroadcastDiscoveryManager", "should_relay_broadcast error: " + std::string(e.what()));
        return false;
    }
}

BroadcastMessage BroadcastDiscoveryManager::create_broadcast_message(
        uint64_t request_id,
        const std::string& source_peer,
        const std::string& target_peer,
        int ttl,
        int hop_count,
        const std::string& signature) {
    
    BroadcastMessage msg;
    msg.request_id = request_id;
    msg.source_peer = source_peer;
    msg.target_peer = target_peer;
    msg.ttl = ttl;
    msg.hop_count = hop_count;
    msg.signature = signature;
    msg.timestamp = std::chrono::steady_clock::now();
    
    return msg;
}

void BroadcastDiscoveryManager::process_discovery_response(const BroadcastMessage& message) {
    try {
        // Find matching pending discovery
        for (auto& [request_id, pending] : m_pending_discoveries) {
            if (pending.request_id == message.request_id &&
                pending.target_peer == message.source_peer) {
                
                // Calculate latency
                auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - pending.start_time).count();
                
                DiscoveryResponse response;
                response.responder_peer = message.source_peer;
                response.hop_count = message.hop_count;
                response.latency_ms = static_cast<int>(elapsed);
                response.timestamp = std::chrono::steady_clock::now();
                
                // Update best latency
                if (response.latency_ms < pending.best_latency) {
                    pending.best_latency = response.latency_ms;
                }
                
                pending.response_count++;
                pending.responses.push_back(response);
                
                // Call callback if registered
                if (pending.callback) {
                    try {
                        pending.callback(request_id, response);
                    } catch (const std::exception& e) {
                        log_error("BroadcastDiscoveryManager", 
                                "Callback error: " + std::string(e.what()));
                    }
                }
                
                log_info("BroadcastDiscoveryManager",
                        "Discovery response received: peer=" + message.source_peer +
                        " latency=" + std::to_string(response.latency_ms) + "ms");
                
                break;
            }
        }
    } catch (const std::exception& e) {
        log_error("BroadcastDiscoveryManager", "process_discovery_response error: " + std::string(e.what()));
    }
}

bool BroadcastDiscoveryManager::is_broadcast_duplicate(const std::string& dedup_key) {
    return m_dedup_cache.find(dedup_key) != m_dedup_cache.end();
}

void BroadcastDiscoveryManager::mark_broadcast_seen(const std::string& dedup_key) {
    m_dedup_cache[dedup_key] = std::chrono::steady_clock::now();
    
    // Cleanup old entries if cache is too large
    if (m_dedup_cache.size() > static_cast<size_t>(m_config.dedup_cache_size)) {
        auto oldest = m_dedup_cache.begin();
        for (auto it = m_dedup_cache.begin(); it != m_dedup_cache.end(); ++it) {
            if (it->second < oldest->second) {
                oldest = it;
            }
        }
        m_dedup_cache.erase(oldest);
    }
}

bool BroadcastDiscoveryManager::is_peer_rate_limited(const std::string& peer_id) {
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        auto it = m_peer_broadcast_count.find(peer_id);
        if (it == m_peer_broadcast_count.end()) {
            return false;
        }
        
        auto& [last_time, count] = it->second;
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_time).count();
        
        // Reset counter if window expired
        if (elapsed >= 60) {
            count = 0;
            return false;
        }
        
        // Check if rate limited
        return count >= m_config.rate_limit_per_min;
    } catch (const std::exception& e) {
        log_error("BroadcastDiscoveryManager", "is_peer_rate_limited error: " + std::string(e.what()));
        return false;
    }
}

void BroadcastDiscoveryManager::record_peer_broadcast(const std::string& peer_id) {
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        auto now = std::chrono::steady_clock::now();
        auto it = m_peer_broadcast_count.find(peer_id);
        
        if (it == m_peer_broadcast_count.end()) {
            m_peer_broadcast_count[peer_id] = {now, 1};
        } else {
            auto& [last_time, count] = it->second;
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_time).count();
            
            if (elapsed >= 60) {
                // Reset counter
                count = 1;
                last_time = now;
            } else {
                count++;
            }
        }
    } catch (const std::exception& e) {
        log_error("BroadcastDiscoveryManager", "record_peer_broadcast error: " + std::string(e.what()));
    }
}

BroadcastDiscoveryManager::DiscoveryStatistics BroadcastDiscoveryManager::get_statistics() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    DiscoveryStatistics stats;
    stats.total_discoveries = m_request_counter;
    stats.active_discoveries = m_pending_discoveries.size();
    stats.dedup_cache_size = m_dedup_cache.size();
    stats.tracked_peers = m_peer_broadcast_count.size();
    
    // Calculate average responses
    int total_responses = 0;
    for (const auto& [_, pending] : m_pending_discoveries) {
        total_responses += pending.response_count;
    }
    
    if (!m_pending_discoveries.empty()) {
        stats.avg_responses_per_discovery = static_cast<float>(total_responses) / 
                                            m_pending_discoveries.size();
    }
    
    return stats;
}

bool BroadcastDiscoveryManager::validate_broadcast_message(const BroadcastMessage& message) {
    if (message.request_id == 0) {
        m_last_error = "Invalid request_id";
        return false;
    }
    
    if (message.source_peer.empty() || message.source_peer.length() > 256) {
        m_last_error = "Invalid source_peer";
        return false;
    }
    
    if (message.ttl <= 0 || message.ttl > m_config.ttl) {
        m_last_error = "Invalid TTL";
        return false;
    }
    
    if (message.hop_count < 0 || message.hop_count > m_config.ttl) {
        m_last_error = "Invalid hop_count";
        return false;
    }
    
    return true;
}

bool BroadcastDiscoveryManager::validate_discovery_response(const DiscoveryResponse& response) {
    if (response.responder_peer.empty() || response.responder_peer.length() > 256) {
        m_last_error = "Invalid responder_peer";
        return false;
    }
    
    if (response.latency_ms < 0 || response.latency_ms > 300000) {  // 5 minutes max
        m_last_error = "Invalid latency";
        return false;
    }
    
    if (response.hop_count < 0 || response.hop_count > m_config.ttl) {
        m_last_error = "Invalid hop_count";
        return false;
    }
    
    return true;
}

std::string BroadcastDiscoveryManager::get_status_json() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    std::ostringstream oss;
    oss << "{\n";
    oss << "  \"running\": " << (m_running ? "true" : "false") << ",\n";
    oss << "  \"request_counter\": " << m_request_counter << ",\n";
    oss << "  \"pending_discoveries\": " << m_pending_discoveries.size() << ",\n";
    oss << "  \"dedup_cache_size\": " << m_dedup_cache.size() << ",\n";
    oss << "  \"tracked_peers\": " << m_peer_broadcast_count.size() << ",\n";
    oss << "  \"config\": {\n";
    oss << "    \"ttl\": " << m_config.ttl << ",\n";
    oss << "    \"dedup_cache_size\": " << m_config.dedup_cache_size << ",\n";
    oss << "    \"rate_limit_per_min\": " << m_config.rate_limit_per_min << ",\n";
    oss << "    \"response_timeout_sec\": " << m_config.response_timeout_sec << "\n";
    oss << "  }\n";
    oss << "}\n";
    
    return oss.str();
}

std::string BroadcastDiscoveryManager::get_last_error() const {
    return m_last_error;
}

// ==================== PRIVATE METHODS ====================

void BroadcastDiscoveryManager::cleanup_loop() {
    while (m_running) {
        try {
            std::this_thread::sleep_for(std::chrono::seconds(60));  // Cleanup every minute
            
            std::lock_guard<std::mutex> lock(m_mutex);
            
            auto now = std::chrono::steady_clock::now();
            
            // Clean old dedup cache entries
            std::vector<std::string> to_remove;
            for (const auto& [key, timestamp] : m_dedup_cache) {
                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - timestamp).count();
                if (elapsed > 3600) {  // 1 hour
                    to_remove.push_back(key);
                }
            }
            
            for (const auto& key : to_remove) {
                m_dedup_cache.erase(key);
            }
            
        } catch (const std::exception& e) {
            log_error("BroadcastDiscoveryManager", "Cleanup loop error: " + std::string(e.what()));
        }
    }
}

void BroadcastDiscoveryManager::response_timeout_loop() {
    while (m_running) {
        try {
            std::this_thread::sleep_for(std::chrono::seconds(5));  // Check every 5 seconds
            
            std::lock_guard<std::mutex> lock(m_mutex);
            
            auto now = std::chrono::steady_clock::now();
            std::vector<uint64_t> to_remove;
            
            for (auto& [request_id, pending] : m_pending_discoveries) {
                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(
                    now - pending.start_time).count();
                
                if (elapsed > m_config.response_timeout_sec) {
                    to_remove.push_back(request_id);
                    
                    // Call callback with timeout notification
                    if (pending.callback && pending.response_count == 0) {
                        try {
                            // Create fake response indicating timeout
                            DiscoveryResponse timeout_response;
                            timeout_response.responder_peer = "TIMEOUT";
                            timeout_response.latency_ms = m_config.response_timeout_sec * 1000;
                            pending.callback(request_id, timeout_response);
                        } catch (const std::exception& e) {
                            log_error("BroadcastDiscoveryManager",
                                    "Timeout callback error: " + std::string(e.what()));
                        }
                    }
                    
                    log_warn("BroadcastDiscoveryManager",
                            "Discovery timeout: request_id=" + std::to_string(request_id) +
                            ", responses=" + std::to_string(pending.response_count));
                }
            }
            
            // Remove timed out discoveries
            for (uint64_t request_id : to_remove) {
                m_pending_discoveries.erase(request_id);
                m_discovery_callbacks.erase(request_id);
            }
            
        } catch (const std::exception& e) {
            log_error("BroadcastDiscoveryManager", "Response timeout loop error: " + std::string(e.what()));
        }
    }
}
