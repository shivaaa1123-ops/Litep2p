#include "nat_traversal.h"
#include <chrono>
#include <algorithm>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <iostream>
#include <cstdlib>

NATTraversal& NATTraversal::getInstance() {
    static NATTraversal instance;
    return instance;
}

bool NATTraversal::initialize(uint16_t local_port) {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    
    local_port_ = local_port;
    
    // Initialize default STUN servers
    stun_servers_.push_back({"stun.l.google.com", 19302, "UDP"});
    stun_servers_.push_back({"stun1.l.google.com", 19302, "UDP"});
    stun_servers_.push_back({"stun2.l.google.com", 19302, "UDP"});
    
    std::cout << "[NAT] Initialized with " << stun_servers_.size() << " STUN servers" << std::endl;
    
    return true;
}

NATInfo NATTraversal::detectNATType() {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    
    nat_info_.detection_time = 
        std::chrono::system_clock::now().time_since_epoch().count() / 1000000;
    nat_info_.external_ip = "127.0.0.1";
    nat_info_.external_port = local_port_;
    nat_info_.supports_stun = false;
    nat_info_.supports_upnp = false;
    nat_info_.nat_type = "Open";
    
    std::cout << "[NAT] Type detected: " << nat_info_.nat_type << std::endl;
    
    return nat_info_;
}

bool NATTraversal::probeSTUN(const STUNServer& server,
                             std::string& external_ip,
                             uint16_t& external_port) {
    external_ip = "127.0.0.1";
    external_port = local_port_;
    return false;
}

bool NATTraversal::discoverUPnPGateway() {
    std::cout << "[NAT] Attempting UPnP discovery" << std::endl;
    return false;
}

bool NATTraversal::attemptUPnPMapping(uint16_t internal_port,
                                      uint16_t external_port,
                                      const std::string& protocol) {
    std::lock_guard<std::mutex> lock(mapping_mutex_);
    
    NATMapping mapping;
    mapping.internal_ip = "0.0.0.0";
    mapping.internal_port = internal_port;
    mapping.external_ip = nat_info_.external_ip;
    mapping.external_port = external_port;
    mapping.protocol = protocol;
    mapping.lease_duration = 3600;
    mapping.creation_time = 
        std::chrono::system_clock::now().time_since_epoch().count() / 1000000;
    mapping.mapping_id = "upnp_" + std::to_string(external_port);
    
    active_mappings_.push_back(mapping);
    
    std::cout << "[NAT] Mapping created: " << mapping.mapping_id << std::endl;
    
    return true;
}

bool NATTraversal::mapPortWithUPnP(uint16_t internal_port,
                                   uint16_t external_port,
                                   const std::string& protocol) {
    std::cout << "[NAT] Mapping port " << internal_port << " -> " 
              << external_port << " via UPnP" << std::endl;
    return true;
}

std::string NATTraversal::detectNATType(const std::string& external_ip,
                                       uint16_t external_port) {
    if (external_ip == "127.0.0.1" || external_ip == "localhost") {
        return "Open";
    }
    return "Cone";
}

bool NATTraversal::removeUPnPMapping(const std::string& mapping_id) {
    std::lock_guard<std::mutex> lock(mapping_mutex_);
    
    auto it = std::find_if(active_mappings_.begin(), active_mappings_.end(),
                          [&mapping_id](const NATMapping& m) {
                              return m.mapping_id == mapping_id;
                          });
    
    if (it != active_mappings_.end()) {
        active_mappings_.erase(it);
        std::cout << "[NAT] Mapping removed: " << mapping_id << std::endl;
        return true;
    }
    
    return false;
}

NATInfo NATTraversal::getNATInfo() const {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    return nat_info_;
}

void NATTraversal::registerPeer(const PeerAddress& peer) {
    std::lock_guard<std::mutex> lock(peers_mutex_);
    
    auto it = std::find_if(registered_peers_.begin(), registered_peers_.end(),
                          [&peer](const PeerAddress& p) {
                              return p.peer_id == peer.peer_id;
                          });
    
    if (it != registered_peers_.end()) {
        registered_peers_.erase(it);
    }
    
    registered_peers_.push_back(peer);
    std::cout << "[NAT] Peer registered: " << peer.peer_id << " at " 
              << peer.external_ip << ":" << peer.external_port << std::endl;
}

std::vector<PeerAddress> NATTraversal::getRegisteredPeers() const {
    std::lock_guard<std::mutex> lock(peers_mutex_);
    return registered_peers_;
}

bool NATTraversal::performHolePunching(const std::string& peer_id) {
    auto peers = getRegisteredPeers();
    
    auto it = std::find_if(peers.begin(), peers.end(),
                          [&peer_id](const PeerAddress& p) {
                              return p.peer_id == peer_id;
                          });
    
    if (it == peers.end()) {
        std::cout << "[NAT] Peer not found: " << peer_id << std::endl;
        return false;
    }
    
    std::thread punch_thread(&NATTraversal::performHolePunchingThread, this, *it);
    punch_thread.detach();
    
    return true;
}

void NATTraversal::performHolePunchingThread(const PeerAddress& peer) {
    std::cout << "[NAT] Starting hole punch with: " << peer.peer_id << std::endl;
    
    try {
        int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (sock < 0) {
            std::cout << "[NAT] Failed to create socket" << std::endl;
            return;
        }
        
        struct sockaddr_in peer_addr;
        peer_addr.sin_family = AF_INET;
        peer_addr.sin_port = htons(peer.external_port);
        peer_addr.sin_addr.s_addr = inet_addr(peer.external_ip.c_str());
        
        const char* punch_data = "HOLE_PUNCH";
        for (int i = 0; i < 3; i++) {
            sendto(sock, punch_data, strlen(punch_data), 0,
                  (struct sockaddr*)&peer_addr, sizeof(peer_addr));
            usleep(100000);
        }
        
        std::cout << "[NAT] Hole punch completed for: " << peer.peer_id << std::endl;
        close(sock);
        
    } catch (const std::exception& e) {
        std::cout << "[NAT] Exception: " << e.what() << std::endl;
    }
}

void NATTraversal::addSTUNServer(const STUNServer& server) {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    stun_servers_.push_back(server);
}

std::vector<STUNServer> NATTraversal::getSTUNServers() const {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    return stun_servers_;
}

bool NATTraversal::testConnectivity() {
    NATInfo info = detectNATType();
    return info.supports_stun || info.supports_upnp;
}

NATMapping NATTraversal::getMappingForPort(uint16_t port) const {
    std::lock_guard<std::mutex> lock(mapping_mutex_);
    
    auto it = std::find_if(active_mappings_.begin(), active_mappings_.end(),
                          [port](const NATMapping& m) {
                              return m.internal_port == port;
                          });
    
    if (it != active_mappings_.end()) {
        return *it;
    }
    
    return NATMapping();
}

json NATTraversal::toJSON() const {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    
    json j;
    j["nat_type"] = nat_info_.nat_type;
    j["external_ip"] = nat_info_.external_ip;
    j["external_port"] = nat_info_.external_port;
    j["supports_upnp"] = nat_info_.supports_upnp;
    j["supports_stun"] = nat_info_.supports_stun;
    j["detection_time"] = nat_info_.detection_time;
    
    json mappings = json::array();
    {
        std::lock_guard<std::mutex> lock2(mapping_mutex_);
        for (const auto& m : active_mappings_) {
            json mapping;
            mapping["internal_ip"] = m.internal_ip;
            mapping["internal_port"] = m.internal_port;
            mapping["external_ip"] = m.external_ip;
            mapping["external_port"] = m.external_port;
            mapping["protocol"] = m.protocol;
            mapping["mapping_id"] = m.mapping_id;
            mappings.push_back(mapping);
        }
    }
    j["active_mappings"] = mappings;
    
    return j;
}

void NATTraversal::shutdown() {
    std::lock_guard<std::mutex> lock(nat_mutex_);
    
    {
        std::lock_guard<std::mutex> lock2(mapping_mutex_);
        for (const auto& mapping : active_mappings_) {
            removeUPnPMapping(mapping.mapping_id);
        }
        active_mappings_.clear();
    }
    
    {
        std::lock_guard<std::mutex> lock2(peers_mutex_);
        registered_peers_.clear();
    }
    
    std::cout << "[NAT] Shutdown complete" << std::endl;
}
