// NOTE: All encryption/decryption functions have been moved to crypto_utils.cpp
// to consolidate the encryption logic and ensure consistent IV handling.
// This file is kept for backward compatibility but crypto_utils should be used instead.
